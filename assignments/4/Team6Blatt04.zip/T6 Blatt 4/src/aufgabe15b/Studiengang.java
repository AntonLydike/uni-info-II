package aufgabe15b;

public class Studiengang {

}
