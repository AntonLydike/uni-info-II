package aufgabe15a;

public class Studiengang {

}
