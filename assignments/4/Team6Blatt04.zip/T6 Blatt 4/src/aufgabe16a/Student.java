package aufgabe16a;

public class Student {
	
}
