package aufgabe19a;

public class Test__ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Wohnung w = new Wohnung(19.5, 128);
		Grundstück g = new Grundstück(1.456e8, 4356177);

		System.out.println(w);
		System.out.println(g);
	}

}
