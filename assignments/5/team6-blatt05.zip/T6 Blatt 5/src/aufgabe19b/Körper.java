package aufgabe19b;

public abstract class Körper {
	public abstract double getVolumen();
}
