package vorgaben;

import java.util.zip.DataFormatException;
import aufgabe8.Property;

public class Aufgabe8Test {

    public static void main(String args[]) {
	try {
	    Property p = new Property(100000.0, 34);
	    p.setPrice(p.getPrice() * 1.1);
	    System.out.println("Fee: " + p.getPrice() * Property.getFee() / 100);
	} catch (DataFormatException e) {
	    System.err.println(e.getMessage());
	}
    }
}
