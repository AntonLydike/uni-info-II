package aufgabe2;

public class A {

	public static void main(String args[]) {
		for (int i = 0; i < 50; i++) {
			System.out.print("  ");
		}

		System.out.print("\n");
	}
}
