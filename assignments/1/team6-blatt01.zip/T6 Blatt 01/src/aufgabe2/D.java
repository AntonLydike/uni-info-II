package aufgabe2;

public class D {

	public static void main(String args[]) {
		System.out.println(Math.random());
	}
}
