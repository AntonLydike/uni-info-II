package aufgabe2;

public class E {

	public static void main(String args[]) {
		System.out.println(Math.sqrt(1.5d));
	}
}
